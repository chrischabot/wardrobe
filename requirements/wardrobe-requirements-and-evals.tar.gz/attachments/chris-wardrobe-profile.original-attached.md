# Chris — Taste, Formation, Preferences and Operating Rules
*A complete wardrobe-system profile, compiled from the 2026 conversation record. Second edition, 14 September 2026, superseding the first draft of 30 August.*

This document is the single source of truth on style for any system that dresses him, shops for him, or argues with him about clothes. It is written to be read in full. No summary, slogan or one-line calibration may stand in for it, because every compressed version produced so far has drifted within a week.

---

## 1. Where the eye comes from

Five formations layer into one sensibility, and all five are live at once.

**Rotterdam.** Dutch by birth and temperament, from a city the war levelled and a family that carried real losses in it. What survives of that is an egalitarian instinct with teeth: a suspicion of hierarchy, a dislike of national myth-making, a preference for sober competence over display. Plainness is not modesty here, it is a position.

**The Sea Scouts, ages eight to sixteen.** Sailing, compass navigation, camping, rafts, stars from a small boat on open water. This is the deepest layer and the one that moves him most: an epistemology in which gear either works or it does not, and nothing else about it matters. The purchase test that grew out of it, in his own framing, is whether an object could survive a night on a small boat.

**Six American years.** The academic Ivy layer, and above all the oxford cloth button-down, which arrived then and never left. American Ivy is admitted because it is the egalitarian version of collegiate dress: a uniform available to anyone who turns up, not a badge issued by an institution.

**A counterculture adolescence.** Sisters of Mercy, Doc Martens, anti-establishment politics. Standing outside the mainstream became a source of identity and safety rather than exclusion, and it persists as a conscious aesthetic position — non-conformist in judgement, never punk, streetwear or hipster in expression.

**London, Elephant and Castle, now.** He dresses in a neighbourhood where visible quality reads against a backdrop of twenty-pound polyester, and he is alert to it without being governed by it. He concluded, after working the question through properly, that comportment and orientation determine how one is received far more than any garment does.

Two side channels feed the same eye. Formative computing on a C64 and Unix terminals gave him a taste for high-contrast restraint and for the future as something built rather than bought. The Levi's 501 compilation of his youth opened a trapdoor into postwar American roots music, and with it a genuine, unembarrassed love of mythologised Americana — the romance admitted knowingly, with the ad-craft behind it admired rather than resented.

---

## 2. The three governing tests

Every verdict in the record passes one or more of these gates.

**Authority from use, never from rank.** A garment earns its place by what someone had to *do* in it: the field, the deck, the scrum, the atelier. It fails when its authority is positional (membership, hierarchy, gatekeeping) or oppositional (tribe signalling). This is why the wardrobe is anti-insignia rather than anti-formal. No logos, no showy hardware, no business-dress signalling. He recoils physically from a large embroidered logo.

**Ritualised utility, or objects that remember somewhere real.** He is drawn exclusively to things that carry their functional origins with them and could still return to that other life: the Paraboot that could walk a mountain, the loden that remembers Tyrolean pine, the jungle jacket that remembers expedition. The opposite category — costumed leisure, workwear styling that has never done any work — fails instantly, however well made.

**The English class register, filtered out.** The wardrobe is Anglo-friendly in cloth and cut and hostile to English class semiotics. The named niche is **the practical academy**: Dutch sobriety, egalitarian American Ivy, English country function, with the gatekeeping stripped out of all three.

---

## 3. The registers he dresses in

- **Home key.** Oxford button-down, chinos, New Balance. In his words: plain, humble, just me. This is the floor, not a fallback, and it should never be the only thing offered.
- **Sprezzatura.** The favourite register: the deliberate near-mistake, formality tension, the rumpled-on-purpose. A washed shirt under a silk knit tie is the archetype.
- **RL and RRL-inflected Ivy.** The newer and much-loved expansion: blue-stripe OCBD with mid-wash jeans, indigo denim button-down over chinos or fatigues, western shirts, double denim. Workcloth admitted to the academy on merit.
- **Field and workwear.** These carry the outerwear: chore coats in their French, Dutch and Ivy variants, the jungle jacket, work coats, the D-43. Loved partly for their reinterpretation histories — the chore coat jumping from workers to protesting students, the surplus jungle jacket subverted by the anti-war movement.
- **The academic blazer, reintroduced August 2026 on new terms.** The City or church blazer stays out. The distraught-professor blazer is back: salt-and-pepper tweed, chestnut houndstooth with a thin blue line, Donegal, warmth that recalls ivy on brick and leaves on the ground. Texture and fleck keep these on the right side of the line; smooth worsted puts them on the wrong one.
- **The fun lane.** Multi-stripe and panelled rugbies, worn loud over quiet trousers, with one sock or shirt picking up a band from the shirt. The rugby passes where the cable or V-neck "polo jumper" fails: muddy university rather than hierarchical university.

**Filtered out entirely:** polo and cable V-neck jumpers, streetwear and punk styling, suit-and-watch professional competition, heritage-as-costume brands, anything with visible branding.

---

## 4. Fabric is neurological, not decorative

Hand-feel is the primary selection driver. He frames his tactile sensitivity as a near-autistic sensory trait and treats it as information rather than fussiness; cloth, sound and space are all deliberate sensory regulation.

**Sings:** lightweight single-ply oxford at roughly 140 g above all else, the open basket weave whose architecture the fingers can read; heavy oxford in winter; Shetland wool; cotton corduroy; heavy flannel; cashmere; dry honest canvas; slub; denim.

**Repels:** sheen of any kind; dressy drape; synthetics and synthetic-content blends; thin linen; sealed or napped surfaces, moleskin included; and merino *sweaters*, which read shiny, flat and smothering. Merino socks are the one working exception and are worn constantly.

**Construction gates.** Cloth must have real weight — a thin, semi-transparent cotton-wool shirt was a failure on those grounds alone. Collars and cuffs must be sewn, never fused; fused feels hard and moves wrongly against the skin, and he feels it even when nobody can see it. Cool-wash-only, no-tumble-dry shirts are not worth the maintenance. Before any new shirtmaker is recommended, cloth weight and collar construction must be verified rather than taken from a listing.

---

## 5. Colour

**Core:** navy and indigo first, then warm neutrals — beige, stone, cream, walnut — then olive and sage.

**Accents:** autumnal, which is to say rust, moss, ochre, burgundy, brick and airforce blue, joined more recently by the saturated oxford voices — cherry, gold, pink, laurel, slate.

**The compositional devices that recur in the outfits he has actually loved:** warm against cool tension; value inversion; saturation discipline, in which complementaries are allowed because both arrive muted; greyed adjacency; echo rather than match; one colour carried at four different depths; and the sock as the single flash or the quiet rhyme.

A standing colour verdict worth keeping: never let a single neutral appear three times in one outfit, and let the foot echo a colour already present higher up rather than repeating the trouser.

---

## 6. What "interesting" actually means

Not a formula. Interest can arrive on any axis: texture against texture, a register worn completely, one saturated voice in a calm frame, a silhouette, or one genuinely loud piece with quietly rhyming supports. The range runs from a white tee, jeans and a cardigan at the quiet end to a panelled rugby at the loud end, and both are him.

The two failure modes are symmetrical and both have been hit in practice:

- **The clown.** Colour on colour on colour, every element shouting. His own correction: he never asked to look like an eighties pop act, and a red rugby with orange trousers wants an off-white or a blue beside it, not a third statement.
- **The drone.** White shirt, blue chino, safe permutations. Jeans and the wide stripe, in his phrase, are the archetype of the unexciting. Safe options are a fallback, never the lead.

The target he named for himself is **the hard-to-place third thing**: respectable, clearly considered, subtly wrong by conventional expectations in ways that reward a second look. Dramatic without trying to announce itself.

---

## 7. Body, fit and sizes

Tall, a little over 1.85 m, rebuilt after significant and sustained weight loss across 2025 and 2026. Chest and waist both 44 inches, unchanged for months; neck 17 inches.

- Jackets and coats: 46 at Drake's, including Games blazers, chores and macs. Private White chart size 6 / XL. De Bonne Facture runs to its own chart and its numbers must never be carried across from Drake's.
- Rugbies: XL. The XXLs that remain are layering pieces and read slouchy.
- Shirts: made to measure at Proper Cloth on the current manual measure; 17½ collar, occasionally 17, at ready-to-wear makers.
- Trousers: 40 waist, 32 length, dropping to 38 for a rise that sits below the waist. Rise matters more than waist: anything lower than the Drake's Games rise slides as he walks.
- Footwear: UK 8.5 across sneakers and Paraboot alike. UK 8 is too small and caused real damage.

Welts and hems must genuinely clear the waist. Stretch is for movement, never for basic fit. Nothing grips, nothing binds. Comfort over distance always outranks aesthetics at the feet.

---

## 8. Hard constraints

These are not preferences and are never traded against a better-looking outfit.

1. **Socks always, wicking merino by default.** No bare-ankle, no sockless, no loafer-without-sock suggestion, in any weather, for any occasion. This is a standing medical rule with no exceptions.
2. **Sneakers only, until he says his feet have healed.** Nerve damage from previously too-small shoes puts the entire welted fleet and the 990v6 out of play; temporary pain would become permanent injury.
3. **Every outfit names both a sneaker and a welted alternative** once the fleet returns, so the day's distance and weather decide at the door rather than in the plan.
4. **The thermal rule.** Shirts and trousers are chosen against the day's *peak* temperature, never the morning low. A day that starts at 11° and reaches 19° is a 19° outfit. Only outerwear answers the morning, because the jacket exists to cover the cool start and then comes off. At roughly 14–16° a jacket goes over a lightweight oxford only; a heavy shirt underneath is far too hot.
5. **Variety horizon is the week, not three days.** He owns twenty-odd trousers and thirty-odd shirts precisely so that nothing repeats inside a fortnight. Anything worn in the last seven days is a repeat.
6. **Never fall back to navy** when a piece is swapped out. He calls it boring, and he is right about his own wardrobe.
7. **Names must match what he can actually see at the wardrobe.** Manufacturer wash names mean nothing to him, and jeans hang as a narrow side profile. Jeans are light, mid or dark. Any question must be answerable from that view alone.

---

## 9. Footwear and accessories

New Balance is the spine: the 990v4 and 990v6 chosen on their merits rather than by habit, with the 993 a genuine complement. The Made in USA and Made in England heritage lines pass the biography test; the tech-runner and gorpcore lines do not. Paraboot occupies the welted half of the fleet across its three bloodlines — the alpine moc, the Norwegian split-toe and the plain city derby — as shoes that can sit at a Paris dinner table and walk a forest path without apology. Loafers are a real and unfulfilled want; no Bass Weejun has ever tempted him, and another Michael is not the answer.

Accessories run to Anderson's woven belts in brown, olive and black; silk knit ties in burgundy, rust, navy and emerald; Drake's printed wool-silk scarves and bandanas; a linen pocket square. The belt line in any plan should carry an optional scarf or tie suggestion appropriate to the day: often ignored, always welcome. Watches and jewellery are absent by choice, and the suit-and-watch register is one he has explicitly refused.

---

## 10. Makers, and how they are judged

Trusted because their objects remember somewhere real: Drake's, Private White V.C., De Bonne Facture, Paraboot, New Balance, Proper Cloth, Anderson's, Cordings, Shetland knitters such as Harley and Campbell's. Rejected on principle: brands wearing their own heritage as costume, retailers inflating recommended prices to manufacture a discount, and anything whose appeal rests on a visible name.

The current consignment of oversized pieces is a size correction and not a verdict. He sold Games blazers, a jungle jacket and rugbies because they no longer fit, and he wants those same categories back in the smaller size. Nothing in the sale should ever be read as a reason to steer him away from a category.

---

## 11. How advice should arrive

Direct and decision-light. He runs on limited sleep and mornings are sacred; a board is a pick, not a negotiation, and a morning correction is a swap rather than a rebuild. Composition happens the evening before, from the forecast, the calendar and the last fortnight's wears.

Verify before asserting. Never state an inventory fact from memory when the ledger can be queried. A zero wear count means unlogged, never unworn, and condition must never be inferred from it. His direct knowledge of reality outranks the ledger every time.

Never flatter, never litigate, never narrate his own words back at him. Correct cleanly in a sentence when wrong, and keep counter-arguments in rather than smoothing them away; he asks to have his weak points attacked and dislikes being catered to. The prose around an outfit should teach a little by osmosis and spark some care for the day, never read as a dry inventory.

The daily entry is one glanceable board: a day line closing on the shape of the day, then five outfits, each opening with a sentence on why it works and what makes it interesting, followed by jacket, shirt or jumper, trousers, belt with its optional flourish, and socks with shoes. Whitespace between everything, built for the half-awake glance rather than the careful read.
